# Releases

## 0.0.1

Initial push of Instana ansible collection. Released focused on the `instana_webhook` module

